export interface AddRecordModel {
    Email: string;
    Name: string;
    Mentor: string;
    Course: string;
    Status:string;
    Remarks:string;
    ExamDate:Date;
    WarningDate:Date;
    R2d2Link:string;
}