import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { AddRecordModel } from 'src/models/add-record-model';

@Injectable({
  providedIn: 'root'
})
export class TrackAppServicesService {

  constructor(private http:HttpClient) { }

  baseurl:string = "https://localhost:7123";

  addRecordByForm(record:AddRecordModel): Observable<void>{
    return this.http.post<void>(`${this.baseurl}/api/TrackApp/AddorUpdate`, record);
  }

  addRecordByImport(filePath: string): Observable<any> {
    const formData = new FormData();
    formData.append('filePath', filePath);
  
    return this.http.post<any>(`${this.baseurl}/api/TrackApp/import`, formData);
  }
  
  
  
  
  getAllRecords(){
    return this.http.get(`${this.baseurl}/api/TrackApp/GetRecords`);
  }
  getRecordByEmail(email:string){
    return this.http.post(`${this.baseurl}/api/TrackApp/searchByEmail`, null, {params:{email:email}});
  }

  updateRecord(email:string, record:AddRecordModel){
    return this.http.put(`${this.baseurl}/api/TrackApp/updateRecord`, record, {params:{email:email}});
  }
  deleteRecord(email:string){
    return this.http.delete(`${this.baseurl}/api/TrackApp/deleteRecord`, {params:{email:email}});
  }
  sendEmail(): Observable<any> {
    return this.http.get(`${this.baseurl}/api/TrackApp/SendMail`);
  }

  migrate(): Observable<any> {
    return this.http.post(`${this.baseurl}/api/TrackApp/Migration`, null);
  }
}
