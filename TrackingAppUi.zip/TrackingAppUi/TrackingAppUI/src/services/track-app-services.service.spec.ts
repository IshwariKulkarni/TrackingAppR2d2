import { TestBed } from '@angular/core/testing';

import { TrackAppServicesService } from './track-app-services.service';

describe('TrackAppServicesService', () => {
  let service: TrackAppServicesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TrackAppServicesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
