import { Component } from '@angular/core';
import { NgToastService } from 'ng-angular-popup';
import { AddRecordModel } from 'src/models/add-record-model';
import { TrackAppServicesService } from 'src/services/track-app-services.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent {
  record: AddRecordModel;
  //filePath: string;
  toast: any;

  constructor(private service: TrackAppServicesService, toast: NgToastService) {
    this.record = {
      Email: '',
      Name: '',
      Mentor: '',
      Course: '',
      Status: '',
      Remarks: '',
      R2d2Link:'',
      ExamDate: new Date(),
      WarningDate: new Date()
    };
   // this.filePath = '';
    this.toast = toast;
  }

  onFormSubmit() {
    this.service.addRecordByForm(this.record)
      .subscribe(
        response => {
          this.toast.success({ detail: "SUCCESS", summary: response, duration: '5000', position: 'topRight' });
        },
        error => {
          const errorMessage = error?.error || 'Error adding or updating data.';
          this.toast.error({ detail: "ERROR", summary: errorMessage, duration: '5000', position: 'topRight' });
        }
      );
  }

  // onFileSubmit() {
  // //  console.log(this.filePath);
  // //  this.service.addRecordByImport(this.filePath)
  //     .subscribe({
  //       next: (response) => {
  //         console.log(response);
  //         this.toast.success({ detail: "SUCCESS", summary: response, duration: '5000', position: 'topRight' });
  //       },
  //       error: (err) => {
  //         console.log(err);
  //         const error = err.error;
  //         this.toast.error({ detail: "ERROR", summary: error, duration: '5000', position: 'topRight' });
  //       }
  //     });
  // }

  // Assuming you have an input field or a method to set the filePath
  // setFilePath(event: any) {
  //   // For example, if you have an input field for file path
  //   this.filePath = event.target.value;
  // }

}
