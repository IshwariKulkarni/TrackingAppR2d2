
import { Component } from '@angular/core';
import { NgToastService } from 'ng-angular-popup';
import { TrackAppServicesService } from 'src/services/track-app-services.service';

@Component({
  selector: 'app-get-all-records',
  templateUrl: './get-all-records.component.html',
  styleUrls: ['./get-all-records.component.css']
})
export class GetAllRecordsComponent {
  records:any[]= [];
  searchTerm: string = '';
  toast: any;
  constructor(private service : TrackAppServicesService,toast:NgToastService) { 
    this.toast = toast;
  }

  getRecords(){
    this.service.getAllRecords()
      .subscribe(response =>this.records = response as any[])
  }

  filterRecords(): any[] {
    return this.records.filter(record =>
      record.email.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      record.name.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
      record.mentor.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }
  DeleteRecord(email:string): void {
    this.service.deleteRecord(email).subscribe((data: any) => {
      console.log(data);
      this.toast.info({detail:"INFO",summary:data,duration:'5000',position:'topRight'});
      this.getRecords();
    });
  }

}
