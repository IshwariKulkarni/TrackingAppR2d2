import { Component, OnInit } from '@angular/core';
import { NgToastService } from 'ng-angular-popup';
import { TrackAppServicesService } from 'src/services/track-app-services.service';
import { interval } from 'rxjs';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  constructor(private service: TrackAppServicesService, private toast: NgToastService) { }

  ngOnInit() {
    // Trigger sendMail every 24 hours
    interval(24 * 60 * 60 * 1000) // 24 hours in milliseconds
      .subscribe(() => {
       this.sendMail();
       this.triggerDataMigration();
      });
  }

  sendMail() {
    console.log('Sending mail...');
    this.service.sendEmail()
      .subscribe({
        next: (response: any) => {
          console.log('Response:', response);
          const summary = response && response.message ? response.message : 'Unknown response';
          this.toast.success({ detail: 'SUCCESS', summary, duration: 5000, position: 'topRight' });
        },
        error: (err) => {
          console.error('Error:', err);
          const summary = err && err.message ? err.message : 'Unknown error';
          this.toast.error({ detail: 'ERROR', summary, duration: 5000, position: 'topRight' });
        }
      });
  }

  triggerDataMigration() {
    this.service.migrate()
      .subscribe({
        next: (response: any) => {
          console.log('Response:', response);
          const summary = response && response.message ? response.message : 'Unknown response';
          this.toast.success({ detail: 'SUCCESS', summary, duration: 5000, position: 'topRight' });
        },
        error: (err) => {
          console.error('Error:', err);
          const summary = err && err.message ? err.message : 'Unknown error';
          this.toast.error({ detail: 'ERROR', summary, duration: 5000, position: 'topRight' });
        }
      });
  }
}
