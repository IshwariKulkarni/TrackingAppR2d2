import { Component } from '@angular/core';
import { NgToastService } from 'ng-angular-popup';
import { TrackAppServicesService } from 'src/services/track-app-services.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  constructor(private service: TrackAppServicesService, private toast: NgToastService) { }

  sendMail() {
    console.log('Sending mail...');
    this.service.sendEmail()
      .subscribe({
        next: (response: any) => {
          console.log('Response:', response);
          const summary = response && response.message ? response.message : 'Unknown response';
          this.toast.success({ detail: 'SUCCESS', summary, duration: 5000, position: 'topRight' });
        },
        error: (err) => {
          console.error('Error:', err);
          const summary = err && err.message ? err.message : 'Unknown error';
          this.toast.error({ detail: 'ERROR', summary, duration: 5000, position: 'topRight' });
        }
      });
  }
  
}
