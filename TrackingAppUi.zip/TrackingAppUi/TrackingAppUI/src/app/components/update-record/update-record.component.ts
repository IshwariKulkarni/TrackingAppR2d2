import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { NgToastService } from 'ng-angular-popup';
import { AddRecordModel } from 'src/models/add-record-model';
import { TrackAppServicesService } from 'src/services/track-app-services.service';

@Component({
  selector: 'app-update-record',
  templateUrl: './update-record.component.html',
  styleUrls: ['./update-record.component.css']
})
export class UpdateRecordComponent {
  formData: AddRecordModel
  email: string;
  toast: any;
  
  constructor(private service: TrackAppServicesService, private route: ActivatedRoute, toast: NgToastService) {
    this.formData = {
      Email: '',
      Name: '',
      Mentor: '',
      Course: '',
      Status: '',
      Remarks: '',
      R2d2Link:'',
      ExamDate: new Date(),
      WarningDate: new Date()
    };
    this.email = '';
    this.toast = toast;
  }
  ngOnInit(): void {
    this.email = this.route.snapshot.paramMap.get('email')|| '';
    this.service.getRecordByEmail(this.email).subscribe((data: any) => {
      this.formData.Email = data.email;
      this.formData.Name = data.name;
      this.formData.Mentor = data.mentor;
      this.formData.Course = data.course;
      this.formData.Status = data.status;
      this.formData.Remarks = data.remarks;
      this.formData.ExamDate = data.examDate;
      this.formData.R2d2Link = data.R2d2Link;
    });
  }
  onSubmit(): void {
    this.service.updateRecord(this.email, this.formData).subscribe((data: any) => {
      this.toast.success({detail:"SUCCESS",summary:data,duration:'5000',position:'topRight'});
    });
  }


}
