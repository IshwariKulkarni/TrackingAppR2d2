import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { NavbarComponent } from './components/navbar/navbar.component';
import { AddRecordComponent } from './components/add-record/add-record.component';
import { HomeComponent } from './components/home/home.component';
import { FormsModule } from '@angular/forms';
import { HttpClientModule} from '@angular/common/http';
import { GetAllRecordsComponent } from './components/get-all-records/get-all-records.component';
import { UpdateRecordComponent } from './components/update-record/update-record.component';
import { NgToastModule } from 'ng-angular-popup';
import { UserComponent } from './components/user/user.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    AddRecordComponent,
    HomeComponent,
    GetAllRecordsComponent,
    UpdateRecordComponent,
    UserComponent,
    
    

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    NgToastModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
