import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddRecordComponent } from './components/add-record/add-record.component';
import { HomeComponent } from './components/home/home.component';
import { GetAllRecordsComponent } from './components/get-all-records/get-all-records.component';
import { UpdateRecordComponent } from './components/update-record/update-record.component';
import { UserComponent } from './components/user/user.component';


const routes: Routes = [
  {
path:'',
component:UserComponent
  },
  {
    path:'home/add-record',
    component:AddRecordComponent
  },
  {
    path:'home',
    component:HomeComponent
  },
  {
    path:'home/get-all-records',
    component:GetAllRecordsComponent
  },
  {
    path:'home/update-record/:email',
    component:UpdateRecordComponent
  },

  {
    path:'user',
    component:UserComponent
  }
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
