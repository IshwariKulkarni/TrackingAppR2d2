﻿namespace TrackingApp.Entities
{
    public class MailData
    {
        public string RecipentMail { get; set; }
        public string RecipentName { get; set; }
        public string MailBody { get; set; }
        public string MailSubject { get; set; }
    }
}
