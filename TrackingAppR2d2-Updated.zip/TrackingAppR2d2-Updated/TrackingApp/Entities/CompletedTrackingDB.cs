﻿using System.ComponentModel.DataAnnotations;

namespace TrackingApp.Entities
{
    public class CompletedTrackingDB
    {
        [Key]
        [Required]
        [EmailAddress(ErrorMessage = "Please Enter a valid email")]
        public string Email { get; set; }
        public string Name { get; set; }
        public string Mentor { get; set; }
        public string Course { get; set; }
        public string Status { get; set; }
        public string Remarks { get; set; }
        public int WarningCode { get; set; }
        public DateTime ExamDate { get; set; }
        public DateTime WarningDateTime { get; set; }
        public string R2d2Link { get; set; }
    }
}
