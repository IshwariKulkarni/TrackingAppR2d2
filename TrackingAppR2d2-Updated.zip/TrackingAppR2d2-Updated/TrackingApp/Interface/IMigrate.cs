﻿namespace TrackingApp.Interface
{
    public interface IMigrate
    {
        Task DataMigration();
    }
}
