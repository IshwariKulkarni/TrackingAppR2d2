﻿namespace TrackingApp.Interface
{
    public interface IEmailServices
    {
        public bool SendMail();
    }
}
