﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;
using System.Threading.Tasks;
using TrackingApp.Entities;
using TrackingApp.Interface;

namespace TrackingApp.Repository
{
    public class CompletedData : IMigrate
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<CompletedData> _logger;

        public CompletedData(IServiceProvider serviceProvider, ILogger<CompletedData> logger)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
        }

        public async Task DataMigration()
        {
            try
            {
                // Create a scope to resolve scoped services
                using (var scope = _serviceProvider.CreateScope())
                {
                    var scopedServices = scope.ServiceProvider;
                    var trackingDbContext = scopedServices.GetRequiredService<TrackingDbContext>();

                    // Move completed records to CompletedTrackingDB table
                    await MoveCompletedRecordsAsync(trackingDbContext);
                }

                _logger.LogInformation("Manual data migration completed successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error in manual data migration: {ex.Message}");
            }
        }

        private async Task MoveCompletedRecordsAsync(TrackingDbContext context)
        {
            _logger.LogInformation("Moving completed records...");

            var completedRecords = context.TrackingDB
                .Where(record =>
                    !string.IsNullOrWhiteSpace(record.Name) &&
                    !string.IsNullOrWhiteSpace(record.Email) &&
                    record.ExamDate != default &&  // Check if ExamDate is not the default DateTime value
                    !string.IsNullOrWhiteSpace(record.Course) &&
                    !string.IsNullOrWhiteSpace(record.Mentor) &&
                    !string.IsNullOrWhiteSpace(record.Status) &&
                    !string.IsNullOrWhiteSpace(record.Remarks) &&
                    !string.IsNullOrWhiteSpace(record.R2d2Link))
                .ToList();

            _logger.LogInformation($"Found {completedRecords.Count} completed records.");

            foreach (var completedRecord in completedRecords)
            {
                try
                {
                    // Move the completed record to CompletedTrackingDB
                    context.CompletedTrackingDB.Add(new CompletedTrackingDB
                    {
                        Email = completedRecord.Email,
                        Name = completedRecord.Name,
                        Mentor = completedRecord.Mentor,
                        Course = completedRecord.Course,
                        Status = completedRecord.Status,
                        Remarks = completedRecord.Remarks,
                        WarningCode = completedRecord.WarningCode,
                        ExamDate = completedRecord.ExamDate,
                        WarningDateTime = completedRecord.WarningDateTime,
                        R2d2Link = completedRecord.R2d2Link
                    });

                    // Remove the completed record from TrackingDB
                    context.TrackingDB.Remove(completedRecord);
                }
                catch (Exception ex)
                {
                    _logger.LogError($"Error moving completed record: {ex.Message}");
                }
            }

            // Save changes once after moving all records
            try
            {
                await context.SaveChangesAsync();
                _logger.LogInformation("Changes saved successfully.");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error saving changes: {ex.Message}");
            }

            _logger.LogInformation("Completed records moved.");
        }
    }
}
