﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using TrackingApp.Entities;
using TrackingApp.Interface;
using Microsoft.Extensions.Logging;

namespace TrackingApp.Repository
{
    public class EmailServices : IEmailServices
    {
        private readonly TrackingDbContext _context;
        private readonly ILogger<EmailServices> _logger;

        public EmailServices(TrackingDbContext context, ILogger<EmailServices> logger)
        {
            _context = context;
            _logger = logger;
        }

        string smtpServer = "smtp.gmail.com";
        string smtpPort = "587";
        string smtpUsername = "khandelwalyash447@gmail.com";   // Enter your Gmail Email Id
        string smtpPassword = "qcisiuhjrfgxmgaq";   // Enter the password associated with the above Gmail Id

        public bool SendMail()
        {
            try
            {
                var list = _context.TrackingDB.ToList();

                bool result = FirstWarningEmail(list) && SecondWarningEmail(list) && ThirdWarningEmail(list);

                if (result)
                {
                    // Update warning codes only if all emails were sent successfully
                    UpdateWarningCodes(list);
                }

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error sending emails: {ex.Message}");
                return false;
            }
        }

        private bool FirstWarningEmail(IEnumerable<TrackingDB> records)
        {
            return SendWarningEmail(records, 0, 24, "First Level Warning", "It's been 24 hours since you scheduled the exam date. Please upload your certificate on the portal: http://localhost:4200/user", 1);
        }

        private bool SecondWarningEmail(IEnumerable<TrackingDB> records)
        {
            return SendWarningEmail(records, 1, 48, "Second Level Warning", "This is the second level warning.\n Warnings:\n1. First Level: You haven't updated your status for more than 24 hours.\n2. Second Level: You haven't updated your status for more than 72 hours.\n3. Third Level: You haven't updated your status for more than 96 hours(This warning will be escalated).", 2);
        }

        private bool ThirdWarningEmail(IEnumerable<TrackingDB> records)
        {
            return SendWarningEmail(records, 2, 96, "Third Level And Final Warning", "This is the third level warning.\n Warnings:\n1. First Level: You haven't updated your status for more than 24 hours.\n2. Second Level: You haven't updated your status for more than 72 hours.\n3. Third Level: You haven't updated your status for more than 96 hours(This warning will be escalated).", 3);
        }

        private bool SendWarningEmail(IEnumerable<TrackingDB> records, int warningCode, int hoursThreshold, string subject, string body, int nextWarningCode)
        {
            try
            {
                bool result = false;
                SmtpClient client = ConfigureSmtpClient();

                var filteredRecords = records.Where(x => x.WarningCode == warningCode && (DateTime.Now - x.ExamDate).TotalHours > hoursThreshold && string.IsNullOrEmpty(x.R2d2Link));

                if (filteredRecords.Any())
                {
                    foreach (var record in filteredRecords)
                    {
                        try
                        {
                            var mailAddress = new MailAddress(record.Email);

                            var message = new MailMessage
                            {
                                From = new MailAddress("khandelwalyash447@gmail.com"),
                                Subject = subject,
                                Body = body
                            };

                            message.To.Add(mailAddress.Address);

                            client.Send(message);
                            result = true;
                        }
                        catch (FormatException ex)
                        {
                            _logger.LogError($"Invalid email address: {record.Email}. Error: {ex.Message}");
                        }
                    }
                }
                else
                {
                    result = true;
                }

                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error sending warning emails: {ex.Message}");
                return false;
            }
        }

        private void UpdateWarningCodes(IEnumerable<TrackingDB> records)
        {
            try
            {
                foreach (var record in records)
                {
                    // Update warning codes here
                    // For example, you can use the logic below:
                    if (record.WarningCode == 0)
                    {
                        record.WarningCode = 1;
                    }
                    else if (record.WarningCode == 1)
                    {
                        record.WarningCode = 2;
                    }
                    else if (record.WarningCode == 2)
                    {
                        record.WarningCode = 3;
                        record.Status = "Escalated";
                        record.Remarks = $"Escalated, and the final warning sent on {DateTime.Now} ";
                    }
                }

                _context.SaveChanges();
            }
            catch (Exception ex)
            {
                _logger.LogError($"Error updating warning codes: {ex.Message}");
            }
        }

        private SmtpClient ConfigureSmtpClient()
        {
            return new SmtpClient(smtpServer, int.Parse(smtpPort))
            {
                Credentials = new NetworkCredential(smtpUsername, smtpPassword),
                EnableSsl = true
            };
        }
    }
}
